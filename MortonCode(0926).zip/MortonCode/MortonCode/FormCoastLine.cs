﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesRaster;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.esriSystem;
using System.Runtime.InteropServices;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace MortonCode
{
    public partial class FormCoastLine : Form
    {
        public FormCoastLine()
        {
            InitializeComponent();
        }

        private string maxLength;
        private string minLength;
        private string meanLength;
        private string yardStickLength;
        public string strFilePath;
        public string strFileName;
        private string layerName;
        private ISpatialReference pSpatialRef;
        
        private static int chunksize = 300;

        private IPolyline Coastline;
        private double radius;
      
        private IGeometryCollection pGeometryCollection;
        private IPoint startCenterPoint;
        private IPoint secondCenterPoint;
        public IPoint newCP;
        
        private IPoint presentCenterPoint;
        
        private IPolygon startCirclePolygon;
        private IPolygon endCirclePolygon;
        
       
        private List<IPoint> initialCenterPoints;
        private List<IPoint> resultCenterPoints;
        
        
        private IWorkspace OpenShapfileWorkspace(string ShapeFilePath)
        {
            IWorkspace ws = null;
            IWorkspaceFactory wsf = new ShapefileWorkspaceFactoryClass(); //using DataSourcesFile
            if (ShapeFilePath != null)
            {
                ws = wsf.OpenFromFile(ShapeFilePath, 0);
            }           
            return ws;
        }

        private IFields CreateFieldsCollection(ISpatialReference spatialReference, esriGeometryType geometryType)
        {
            IFeatureClassDescription fcDesc = new FeatureClassDescriptionClass();
            IObjectClassDescription ocDesc = fcDesc as IObjectClassDescription;

            IFields fields = ocDesc.RequiredFields;
            IFieldsEdit fieldsEdit = fields as IFieldsEdit;

            int shapeFieldIndex = fields.FindField(fcDesc.ShapeFieldName);
            IField shapeField = fields.get_Field(shapeFieldIndex);

            IGeometryDef geometryDef = shapeField.GeometryDef;
            IGeometryDefEdit geometryDefEdit = geometryDef as IGeometryDefEdit;

            geometryDefEdit.GeometryType_2 = geometryType;
            geometryDefEdit.GridCount_2 = 1;
            geometryDefEdit.set_GridSize(0, 0);
            geometryDefEdit.SpatialReference_2 = spatialReference;

            return fields;
        }

        private IFeatureClass CreateNewFeatureClass(IWorkspace pWS, String featureClassName, IFields pFields, esriFeatureType pEsriFeatureType) 
        {
            IFeatureClassDescription fcDesc = new FeatureClassDescriptionClass();
            IObjectClassDescription ocDesc = fcDesc as IObjectClassDescription;
            IFieldChecker pFieldChecker = new FieldCheckerClass();
            IEnumFieldError pEnumFieldError = null;
            IFields validatedFields = null;
            IFeatureWorkspace pFeatureWorkspace = pWS as IFeatureWorkspace;
            pFieldChecker.ValidateWorkspace = pWS;
            pFieldChecker.Validate(pFields, out pEnumFieldError, out validatedFields);

            IFeatureClass pFeatureClass = pFeatureWorkspace.CreateFeatureClass(featureClassName, validatedFields, ocDesc.InstanceCLSID, ocDesc.ClassExtensionCLSID, pEsriFeatureType, fcDesc.ShapeFieldName, "");
            return pFeatureClass;
        }

        private void AddGeometryColToFeatureClass(IGeometryCollection pGeometryCollection, IFeatureClass pFeatureClass)
        {
            IFeatureCursor pFeatureCursor;
            IFeatureBuffer pFeatureBuffer;

            pFeatureCursor = pFeatureClass.Insert(true);
            pFeatureBuffer = pFeatureClass.CreateFeatureBuffer();

            IFields pFields;
            IField pField;

            pFields = pFeatureClass.Fields;


            for (int i = 0; i < pGeometryCollection.GeometryCount; i++)
            {
                IGeometry pCurrentGeometry = pGeometryCollection.get_Geometry(i) as IGeometry;

                for (int n = 1; n <= pFields.FieldCount - 1; n++)
                {
                    pField = pFields.get_Field(n);

                    if (pField.Type == esriFieldType.esriFieldTypeGeometry)
                    {

                        pFeatureBuffer.set_Value(n, pCurrentGeometry);


                    }

                }
                pFeatureCursor.InsertFeature(pFeatureBuffer);
            }
            pFeatureCursor.Flush();

        }

        //Geometry Type must be point polyline polygon...
        public void CreateShpfile(String featureClassName, IGeometryCollection pGeometryCollection) 
        {
            GetWorkPath();
            IWorkspace pWS = OpenShapfileWorkspace(this.strFilePath);
            GetSpatialReference();
            ISpatialReference pSpatialReference = this.pSpatialRef;
            IGeometry pGeometry = pGeometryCollection.get_Geometry(0);
            esriGeometryType GeometryType = pGeometry.GeometryType;
            IFields pFields = CreateFieldsCollection(pSpatialReference, GeometryType);
            IFeatureClass pFeatureClass = CreateNewFeatureClass(pWS, featureClassName, pFields, esriFeatureType.esriFTSimple);
            AddGeometryColToFeatureClass(pGeometryCollection, pFeatureClass);
            MessageBox.Show("The shapefile: "+featureClassName+" has been saved in the same directory");
        }

        private void GetWorkPath() //get the path of the first layer in the TOC table
        {
            IMap pMap = axTOCControl1.ActiveView.FocusMap;
            try
            {
                ILayer pLayer = pMap.Layer[0];
                // get first layer of the Map           
                IFeatureLayer pFLayer = pLayer as IFeatureLayer;
                IFeatureClass pFC = pFLayer.FeatureClass;
                /// get dataset of the standalone feature class
                IDataset pDataset = pFC as IDataset;
                IWorkspace pWS = pDataset.Workspace;
                this.strFilePath = pWS.PathName;
                // get selected layers
                object legendGroup = new object();
                object index = new object();
                IBasicMap map = new MapClass();
                ILayer layer = new FeatureLayerClass();
                esriTOCControlItem item = new esriTOCControlItem();
                axTOCControl1.GetSelectedItem(ref item, ref map, ref layer, ref legendGroup, ref index);
                if (item == esriTOCControlItem.esriTOCControlItemLayer) 
                {
                    MessageBox.Show("Selected layer name: "+ layer.Name);
                } 
            }
            catch
            {
                MessageBox.Show("Add at least one layer to the map");              
            }
        }

        private void GetSpatialReference() 
        {
            try
            {
                IMap pMap = axTOCControl1.ActiveView.FocusMap;
                ILayer pLayer = pMap.Layer[0];
                // get first layer of the Map           
                IFeatureLayer pFLayer = pLayer as IFeatureLayer;
                this.pSpatialRef = pMap.SpatialReference;
            }
            catch
            {
                MessageBox.Show("Add at least one layer to the map");
            }
        }

        private void removeData() 
        {
            IMap map = axTOCControl1.ActiveView.FocusMap;
            ILayer layer = null;
            for (int i = 0; i < map.LayerCount; i++) 
            {
                if (map.get_Layer(i).Name == layerName) 
                {
                    layer = map.get_Layer(i);
                }
            }
               
            axTOCControl1.ActiveView.FocusMap.DeleteLayer(layer);
            //axTOCControl1.Update();
            axTOCControl1.ActiveView.Refresh();
            axMapControl1.ActiveView.Refresh();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            GetWorkPath();
            IWorkspace ws = OpenShapfileWorkspace(this.strFilePath);
            IFeatureWorkspace pFWS = ws as IFeatureWorkspace;
            
            if (strFileName == null || strFileName != "UK_CoastlineSplit") 
            {
                MessageBox.Show("Please select the CoastlineSplit in TOC");
                return;
            }
            IFeatureClass fcCoastLineSplit = pFWS.OpenFeatureClass(strFileName);
            //IQueryFilter queryFilter = new QueryFilterClass();
            ICursor cursor = (ICursor)fcCoastLineSplit.Search(null, false);
            //Get statistic of length field and get min and max values
            IDataStatistics dataStatistic = new DataStatisticsClass();
            int fieldindex = fcCoastLineSplit.Fields.FindField("length");
            if (fieldindex == -1)
            {
                MessageBox.Show("Please add 'length' field!");
                return;
            }
            dataStatistic.Field = "length";
            dataStatistic.Cursor = cursor;
            ESRI.ArcGIS.esriSystem.IStatisticsResults staResult = dataStatistic.Statistics;
            // round the result in 4 decimals
            maxLength = Math.Round(staResult.Maximum, 4).ToString();
            minLength = Math.Round(staResult.Minimum, 4).ToString();
            meanLength = Math.Round(staResult.Mean, 4).ToString();
            textBox2.Text = minLength;
            textBox3.Text = maxLength;
            textBox4.Text = meanLength;
            // If minimum length is smaller than 1 meter, set the minimum to the minimum value greater than 1 meter
            if (staResult.Minimum <= 1) 
            {
                if (MessageBox.Show("The minimum length is shorter than 1 meter, change the minimum value greater than 1?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes) 
                {
                    IQueryFilter queryFilter = new QueryFilterClass();
                    queryFilter.WhereClause = "length > 1";
                    ISelectionSet pSelectionSet = fcCoastLineSplit.Select(queryFilter, esriSelectionType.esriSelectionTypeHybrid, esriSelectionOption.esriSelectionOptionNormal, null);
                    IFeatureCursor pFCursor;
                    ICursor pCursor;
                    pSelectionSet.Search(null, true, out pCursor);
                    pFCursor = pCursor as IFeatureCursor;
                    dataStatistic = new DataStatisticsClass();
                    dataStatistic.Field = "length";
                    dataStatistic.Cursor = pCursor;
                    staResult = dataStatistic.Statistics;
                    minLength = Math.Round(staResult.Minimum, 4).ToString();
                    textBox2.Text = minLength;
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            removeData();
        }

        private void axTOCControl1_OnMouseDown(object sender, ITOCControlEvents_OnMouseDownEvent e)
        {
            axTOCControl1.ContextMenuStrip = contextMenuStrip1;
            //judge the type of item selected in the TOC 
            IBasicMap map = new MapClass();
            ILayer layer = null; 
            System.Object other = null;
            System.Object index = null;
            esriTOCControlItem item = esriTOCControlItem.esriTOCControlItemNone;
            axTOCControl1.HitTest(e.x, e.y, ref item, ref map, ref layer, ref other, ref index);
            if (e.button == 2 && item == esriTOCControlItem.esriTOCControlItemLayer) 
            {
                //transfer the screen point location to form location to popup the contextmenu
                System.Drawing.Point p = new System.Drawing.Point();
                p.X = e.x;
                p.Y = e.y;
                p = this.axTOCControl1.PointToScreen(p);
                this.contextMenuStrip1.Show(p);
                layerName = layer.Name;
            }
            if (e.button == 1 && item == esriTOCControlItem.esriTOCControlItemLayer) 
            {
                strFileName = layer.Name;
            }
        }

        private void initialCoastLine() 
        {
            if (strFilePath == null)
            {
                return;
            }
            IWorkspace ws2 = OpenShapfileWorkspace(strFilePath);
            IFeatureWorkspace pFWS2 = ws2 as IFeatureWorkspace;
            //Only one feature in the featureclass
            IFeatureClass fcCoastLine = pFWS2.OpenFeatureClass("UK_Coastline");
            IFeature fCoastLine = fcCoastLine.GetFeature(0);
            //NOTE!!! Use SHAPECOPY NOT SHAPE!!!
            //Initialize coastline;
            Coastline = fCoastLine.ShapeCopy as IPolyline;
  
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") 
            {
                MessageBox.Show("Please input the yardstick length");
                return;
            }
            
            //Start main functions...
            GetWorkPath();
            if (strFilePath == null)
            {
                return;
            }
            IWorkspace ws = OpenShapfileWorkspace(strFilePath);
            IFeatureWorkspace pFWS = ws as IFeatureWorkspace;

            //Only one feature in the featureclass
            IFeatureClass fcCoastLine= pFWS.OpenFeatureClass("UK_Coastline");
            IFeature fCoastLine = fcCoastLine.GetFeature(0);
            IPolyline polylineCoast = new PolylineClass();
            polylineCoast=fCoastLine.ShapeCopy as IPolyline;
            //NOTE!!! Use SHAPECOPY NOT SHAPE!!!
            //Initialize coastline;
            Coastline = fCoastLine.ShapeCopy as IPolyline;
            this.pSpatialRef = Coastline.SpatialReference;
            yardStickLength = textBox1.Text;
            radius = double.Parse(yardStickLength);

            IFeatureClass fcVertices = pFWS.OpenFeatureClass("UK_CoastlineVertices");

            startCenterPoint = fcVertices.GetFeature(0).ShapeCopy as IPoint;

            ICircularArc startCircle;
            startCircle = CreateCircleArc(startCenterPoint, radius, false);
            //Initialize startcirlcePolygon
            startCirclePolygon = Arc2Polygon(startCircle);
            //Get first Intersct points
            IPointCollection firstPointColl = IntersectPointColl(startCircle, polylineCoast);
            MessageBox.Show("first intersect point: " + firstPointColl.PointCount.ToString());

            //判断交点个数
            if (firstPointColl.PointCount != 2)
            {
                initialCenterPoints = GetCorrectPointInitial(SplitPolyline(polylineCoast, firstPointColl, startCenterPoint), startCenterPoint);
            }
            else
            {
                IPoint pt1 = firstPointColl.get_Point(0) as IPoint;
                IPoint pt2 = firstPointColl.get_Point(1) as IPoint;
                List<IPoint> ptlist = new List<IPoint>();
                ptlist.Add(pt1);
                ptlist.Add(pt2);
                initialCenterPoints = ptlist;

            }
            //确定第二个圆心位置
            if (initialCenterPoints.Count == 2)
            {
                if (initialCenterPoints[0].X > initialCenterPoints[1].X)
                {
                    secondCenterPoint = initialCenterPoints[0];
                }
                else
                {
                    secondCenterPoint = initialCenterPoints[1];
                }
                MessageBox.Show("The second circle center is X " + secondCenterPoint.X + " Y " + secondCenterPoint.Y);
            }
            else
            {
                MessageBox.Show("Initialize failed");
            }
        }

        private List<IPoint> SplitPolyline(IPolyline polyline, IPointCollection intersectpointsColl, IPoint presentCP) 
        {
            IEnumVertex pEnumVertex = intersectpointsColl.EnumVertices;
            //IPolycurve2 has SplitAtPoints

            IPolycurve2 pPolyCurve = polyline as IPolycurve2;           
            pPolyCurve.SplitAtPoints(pEnumVertex,false,true,-1);
            IGeometryCollection geoColl = pPolyCurve as IGeometryCollection;
            
            //MessageBox.Show(geoColl.GeometryCount.ToString());
            List<IPoint> ptlist = new List<IPoint>();
            // The results are pathclass
            IPath resultPath;
            for (int i = 0; i < geoColl.GeometryCount; i++) 
            {
                object obj = Type.Missing;
                resultPath = new PathClass();
                resultPath = (IPath)geoColl.get_Geometry(i);
                IGeometryCollection lineColl = new PolylineClass();
                lineColl.AddGeometry(resultPath, ref obj, ref obj);
                IPolyline line = (IPolyline)lineColl;                
                IRelationalOperator pRelOperator = (IRelationalOperator)line;
                if (pRelOperator.Touches(presentCP)||pRelOperator.Contains(presentCP))
                {
                    IPoint temPT1 = resultPath.FromPoint;
                    IPoint temPT2 = resultPath.ToPoint;
                    //pGeometryCollection.AddGeometry(temPT1);
                    //pGeometryCollection.AddGeometry(temPT2);
                    ptlist.Add(temPT1);
                    ptlist.Add(temPT2);                    
                }
            }
            return ptlist;
        }

        private IPoint GetCorrectPointNew(IPolyline polyline,  IPointCollection intersectpointsColl, IPoint presentCP)
        {

            IEnumVertex pEnumVertex = intersectpointsColl.EnumVertices;
            //IPolycurve2 has SplitAtPoints
            IClone clonePolyline = polyline as IClone;
            IPolycurve2 pPolyCurve = clonePolyline.Clone() as IPolycurve2;
            pPolyCurve.SpatialReference = this.pSpatialRef;

            pPolyCurve.SplitAtPoints(pEnumVertex, false, true, 0.1);
            IGeometryCollection geoColl = pPolyCurve as IGeometryCollection;
            //MessageBox.Show(geoColl.GeometryCount.ToString());
            IPoint correctPT = new PointClass(); ;
            // The results are pathclass
            IPath resultPath=null;
            for (int i = 0; i < geoColl.GeometryCount; i++)
            {
                object obj = Type.Missing;
                resultPath = new PathClass();
                resultPath = (IPath)geoColl.get_Geometry(i);
                IGeometryCollection lineColl = new PolylineClass();
                lineColl.AddGeometry(resultPath, ref obj, ref obj);
                IPolyline line = (IPolyline)lineColl;
                IRelationalOperator pRelOperator = (IRelationalOperator)line;
                if (pRelOperator.Touches(presentCP) || pRelOperator.Contains(presentCP))
                {
                    
                    correctPT = resultPath.ToPoint;
                    correctPT.SpatialReference = this.pSpatialRef;
                    //pGeometryCollection.AddGeometry(temPT1);
                    //pGeometryCollection.AddGeometry(temPT2);
                    //ptlist.Add(temPT1);
                }
            }
            Marshal.ReleaseComObject(pEnumVertex);
            
            return correctPT;
        }

        private List<IPoint> GetCorrectPointInitial(List<IPoint> splitresult, IPoint lastCP) 
        {
            List<IPoint> correctPT = new List<IPoint>();
            IRelationalOperator rel=lastCP as IRelationalOperator;
            foreach (IPoint pt in splitresult) 
            {
                if (!rel.Equals(pt))
                {
                    correctPT.Add(pt);
                }
            }
            return correctPT;
        } 

        private bool IsNewPoint(IPoint Point, IPolygon lastcircle) 
        {
            IRelationalOperator pRelOperator = (IRelationalOperator)lastcircle;
            if (pRelOperator.Contains(Point))
            {
                return false;
            }
            else 
            {
                return true;
            }
        }

        private IPointCollection AddVerticePointToCollection(IPolyline coastline) 
        {
            //IPointCollection4
            IPointCollection4 verticePointColl = (IPointCollection4)coastline;         
            return verticePointColl;
        }

        private ICircularArc CreateCircleArc(IPoint point, double radius, bool isCounterCW) 
        {
            ICircularArc circularArc = new CircularArcClass();
            IConstructCircularArc2 constructCircularArc = circularArc as IConstructCircularArc2;
            constructCircularArc.ConstructCircle(point,radius,isCounterCW);
            circularArc.SpatialReference = this.pSpatialRef;
            return circularArc;
        }

        private IPointCollection IntersectPointColl(ICircularArc circularArc, IPolyline coastline) 
        {
            IPolyline circlePolyline = new PolylineClass(); 
            circlePolyline=Arc2Polyline(circularArc);
            circlePolyline.SpatialReference = this.pSpatialRef;
            ITopologicalOperator5 topOperator;

            
                topOperator = ((IClone)circlePolyline).Clone() as ITopologicalOperator5;

                if (!topOperator.IsKnownSimple)
                {
                    topOperator.Simplify();
                }

                IGeometry interGeometry;
                interGeometry=topOperator.Intersect(coastline, esriGeometryDimension.esriGeometry0Dimension) as IGeometry;
                interGeometry.SpatialReference = this.pSpatialRef;

                IPointCollection interPointColl = (IPointCollection)interGeometry;

                //if (topOperator != null)
                //{
                //    Marshal.FinalReleaseComObject(topOperator);
                //    Marshal.FinalReleaseComObject(circlePolyline);
                //    Marshal.FinalReleaseComObject(interGeometry);
                //}
                return interPointColl;          
   
        }
       
        private IPolyline Arc2Polyline(ICircularArc Arc) 
        {
            object obj = Type.Missing;
            ISegmentCollection segC = new PolylineClass();
            segC.AddSegment((ISegment)Arc,ref obj,ref obj);
            IPolyline circlePolyline = (IPolyline)segC;
            // mirror spatial referrence
            circlePolyline.SpatialReference = this.pSpatialRef;
            return circlePolyline;
        }

        private IPolyline Seg2Polyline(ISegment Seg) 
        {
            object obj = Type.Missing;
            ISegmentCollection segC = new PolylineClass();
            segC.AddSegment((ISegment)Seg, ref obj, ref obj);
            IPolyline SegPolyline = (IPolyline)segC;
            // mirror spatial referrence
            SegPolyline.SpatialReference = this.pSpatialRef;
            return SegPolyline;
        }

        private IPolygon Arc2Polygon(ICircularArc Arc) 
        {
            ISegmentCollection pSegCol = new RingClass();
            object obj = Type.Missing;
            pSegCol.AddSegment((ISegment)Arc,ref obj, ref obj);
            //enclose ring make it valid
            IRing pRing;
            pRing = pSegCol as IRing;
            pRing.Close();
            IGeometryCollection pPolygonCol = new PolygonClass();
            pPolygonCol.AddGeometry(pRing,ref obj,ref obj);
            IPolygon circlePolygon=(IPolygon)pPolygonCol;
            // mirror spatial referrence
            circlePolygon.SpatialReference = this.pSpatialRef;
            return circlePolygon;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (secondCenterPoint == null) 
            {
                MessageBox.Show("Initialize first!");
                return;
            }
            //resultCenterPoints = new List<IPoint>();
            //resultCenterPoints.Add(startCenterPoint);
            //resultCenterPoints.Add(secondCenterPoint);
            pGeometryCollection = new GeometryBagClass();
            pGeometryCollection.AddGeometry(startCenterPoint);
            pGeometryCollection.AddGeometry(secondCenterPoint);

            presentCenterPoint = secondCenterPoint;
            IRelationalOperator relCircle = startCirclePolygon as IRelationalOperator;

            while (!relCircle.Contains(presentCenterPoint))
            {
                presentCenterPoint = CreateNewCenterPoint3(presentCenterPoint);
                pGeometryCollection.AddGeometry(presentCenterPoint);

                if (pGeometryCollection.GeometryCount == chunksize) 
                {
                    MessageBox.Show("More veritces created, press 'part' button");
                    break;
                }               
            }
            
            if (MessageBox.Show("Create vertices shapefile?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes) 
            {
                CreateShpfile("Vertices0", pGeometryCollection);
            }         
            
            //...Create yardstick using the generated vertices...
            if (MessageBox.Show("Finish generating vertices, create yardsticks?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                pGeometryCollection = GenerateYardSticks(pGeometryCollection);
                CreateShpfile("Yardsticks0".ToString(), pGeometryCollection);
            }
            else 
            {
                return;
            }
            
        }

        private IGeometryCollection GenerateYardSticks(IGeometryCollection verticesColl) 
        {
            IPoint startPT=new PointClass();
            IPoint endPT = new PointClass();
            IGeometryCollection yardstickColl=new GeometryBagClass();
            ISegmentCollection yardsegColl = new PolylineClass();            
            object obj = Type.Missing;
            for (int i = 0; i < verticesColl.GeometryCount; i++) 
            {
                if (i < verticesColl.GeometryCount - 1)
                {
                    ILine pLine = new LineClass();
                    
                    startPT = verticesColl.get_Geometry(i) as IPoint;
                    endPT = verticesColl.get_Geometry(i + 1) as IPoint;
                    pLine.PutCoords(startPT, endPT);
                    yardsegColl.AddSegment(pLine as ISegment, ref obj, ref obj);                                   
                }
                else 
                {
                    MessageBox.Show(i+" yardsticks generated");
                }
            }
            IPolyline pPolyline = (IPolyline)yardsegColl; 
            yardstickColl.AddGeometry(pPolyline, ref obj, ref obj);
            return yardstickColl;
        }

   

        private IPoint CreateNewCenterPoint2(IPoint presentCP)
        {
            ////initialCoastLine();
            //newCP = new PointClass();           
            //IPolyline line = new PolylineClass();
            //line = Coastline;
            //ICircularArc presentCA = CreateCircleArc(presentCP, radius, false);
            //IPointCollection intersectPtColl = IntersectPointColl(presentCA, line);
            
            

            //newCP = GetCorrectPointNew(line, intersectPtColl, presentCP);
            //if (intersectPtColl != null) 
            //{
            //    Marshal.FinalReleaseComObject(intersectPtColl);
            //    Marshal.FinalReleaseComObject(presentCA);
            //}
            //return newCP;

            ICircularArc presentCA = CreateCircleArc(presentCP, radius, false);
            IPolyline circlePolyline =  Arc2Polyline(presentCA);        
            circlePolyline.SpatialReference = this.pSpatialRef;
            circlePolyline.SnapToSpatialReference();
            ITopologicalOperator2 topOperator=((IClone)circlePolyline).Clone() as ITopologicalOperator2;
            if (!topOperator.IsKnownSimple)
            {
                topOperator.Simplify();
            }
            IGeometry interGeometry = topOperator.Intersect(Coastline, esriGeometryDimension.esriGeometry0Dimension) as IGeometry;
            interGeometry.SpatialReference = this.pSpatialRef;
            interGeometry.SnapToSpatialReference();
            IPointCollection interPointColl = (IPointCollection)interGeometry;
            IPoint NPT = GetCorrectPointNew(Coastline, interPointColl, presentCP);
            Marshal.FinalReleaseComObject(topOperator);
            Marshal.FinalReleaseComObject(circlePolyline);
            Marshal.FinalReleaseComObject(interGeometry);                         
            return NPT;
        }

        private IPoint CreateNewCenterPoint3(IPoint presentCP) 
        {
            ICircularArc presentCA = null;
            IConstructCircularArc2 constructCircularArc = null;
            IGeometry intersectPoints=null;
            ISegmentCollection segC = null;
            IPolyline circlePolyline = null;
            ITopologicalOperator2 topOperator = null;
            IPointCollection PointColl = null;
            IEnumVertex pEnumVertex = null;
            IClone coastlineClone = null;
            IPolycurve2 pPolyCurve = null;
            IGeometryCollection geoColl = null;
            IPoint newCenter = null;
            IPath resultPath = null;
            IGeometryCollection lineColl = null;
            IPolyline line = null;
            IRelationalOperator pRelOperator = null;          
            try 
            {
                //CREATE ARC
                presentCA = new CircularArcClass();
                constructCircularArc = presentCA as IConstructCircularArc2;
                constructCircularArc.ConstructCircle(presentCP, radius, false);
                presentCA.SpatialReference = this.pSpatialRef;
                //ARC 2 POLYLINE
                segC = new PolylineClass();
                segC.AddSegment((ISegment)presentCA);
                circlePolyline = (IPolyline)segC;
                circlePolyline.SpatialReference = this.pSpatialRef;
                //GET INTERSECTIONS
                topOperator = circlePolyline as ITopologicalOperator2;
                intersectPoints = topOperator.Intersect(Coastline, esriGeometryDimension.esriGeometry0Dimension);
                PointColl = (IPointCollection)intersectPoints;
                //SPLIT COASTLINE
                pEnumVertex = PointColl.EnumVertices;
                //COPY COASTLINE 
                coastlineClone = Coastline as IClone;
                pPolyCurve = coastlineClone.Clone() as IPolycurve2;
                pPolyCurve.SplitAtPoints(pEnumVertex, false, true, 0.1);

                geoColl = pPolyCurve as IGeometryCollection;

                newCenter = new PointClass(); ;

                for (int i = 0; i < geoColl.GeometryCount; i++)
                {
                    resultPath = new PathClass();
                    resultPath = (IPath)geoColl.get_Geometry(i);
                    lineColl = new PolylineClass();
                    lineColl.AddGeometry(resultPath);
                    line = (IPolyline)lineColl;
                    pRelOperator = (IRelationalOperator)line;
                    if (pRelOperator.Touches(presentCP) || pRelOperator.Contains(presentCP))
                    {
                        newCenter = resultPath.ToPoint;
                        newCenter.SpatialReference = this.pSpatialRef;
                    }
                }

                return newCenter;               
            }
            finally
            {
                //Marshal.ReleaseComObject(presentCA);
                //Marshal.ReleaseComObject(constructCircularArc);
                //Marshal.ReleaseComObject(intersectPoints);
                //Marshal.ReleaseComObject(segC);
                //Marshal.ReleaseComObject(circlePolyline);
                //Marshal.ReleaseComObject(topOperator);
                //Marshal.ReleaseComObject(PointColl);
                //Marshal.ReleaseComObject(pEnumVertex);
                //Marshal.ReleaseComObject(coastlineClone);
                //Marshal.ReleaseComObject(pPolyCurve);
                //Marshal.ReleaseComObject(geoColl);
                //Marshal.ReleaseComObject(newCenter);
                //Marshal.ReleaseComObject(resultPath);
                //Marshal.ReleaseComObject(lineColl);
                //Marshal.ReleaseComObject(line);
                //Marshal.ReleaseComObject(pRelOperator);
               
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {

            strFilePath = @"D:\study\ao\MortonCode\UKCoastline";
            IWorkspace ws = OpenShapfileWorkspace(strFilePath);
            IFeatureWorkspace pFWS = ws as IFeatureWorkspace;
            openFileDialog1.Filter = "shapefile(*.shp)|*.shp";
            openFileDialog1.InitialDirectory = strFilePath;
            string verticepartname=null;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                int index = openFileDialog1.FileName.LastIndexOf(@"\");
                strFilePath = openFileDialog1.FileName.Substring(0, index);
                int length = openFileDialog1.FileName.Length - strFilePath.Length - 1;
                verticepartname = openFileDialog1.FileName.Substring(index + 1, length);
            }
            //Only one feature in the featureclass
            IFeatureClass fcCoastLine = pFWS.OpenFeatureClass("UK_Coastline");
            IFeature fCoastLine = fcCoastLine.GetFeature(0);
            IPolyline polylineCoast = new PolylineClass();
            polylineCoast = fCoastLine.ShapeCopy as IPolyline;
           
            Coastline = fCoastLine.ShapeCopy as IPolyline;
            this.pSpatialRef = Coastline.SpatialReference;

            textBox1.Text = "3000";
            textBox1.Refresh();
            yardStickLength = textBox1.Text;
            radius = double.Parse(yardStickLength);

            IFeatureClass fcVertices = pFWS.OpenFeatureClass(verticepartname);
            
            if (fcVertices == null) 
            {
                MessageBox.Show("Check vertice file name");
                return;
            }
            startCenterPoint = fcVertices.GetFeature(chunksize-1).ShapeCopy as IPoint;
            
            ICircularArc endcircle;
            endcircle = CreateCircleArc(polylineCoast.ToPoint, radius, false);
            //Initialize startcirlcePolygon
            endCirclePolygon = Arc2Polygon(endcircle);

            secondCenterPoint = CreateNewCenterPoint3(startCenterPoint);
            pGeometryCollection = new GeometryBagClass();
            
            pGeometryCollection.AddGeometry(secondCenterPoint);

            presentCenterPoint = secondCenterPoint;
            IRelationalOperator relCircle = endCirclePolygon as IRelationalOperator;

            while (!relCircle.Contains(presentCenterPoint))
            {
                presentCenterPoint = CreateNewCenterPoint3(presentCenterPoint);
                pGeometryCollection.AddGeometry(presentCenterPoint);

                if (pGeometryCollection.GeometryCount == chunksize)
                {
                    break;
                }
            }
            
            int fileindex=int.Parse((verticepartname[verticepartname.Length-1-4]).ToString())+1;
            
            if (MessageBox.Show("Vertice number: "+pGeometryCollection.GeometryCount.ToString() + " Create vertices shapefile?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                CreateShpfile("Vertices"+fileindex.ToString(), pGeometryCollection);
            }

            //...Create yardstick using the generated vertices...
            if (MessageBox.Show("Finish generating vertices, create yardsticks?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                pGeometryCollection = GenerateYardSticks(pGeometryCollection);
                CreateShpfile("Yardsticks" + fileindex.ToString(), pGeometryCollection);
            }
            
            if (pGeometryCollection.GeometryCount == chunksize)
            {
                Application.Restart();
            }
            else 
            {
                MessageBox.Show("Finished!");
            }
            
        }
        

        
        



      

       
        
        


       
        
    }
}
