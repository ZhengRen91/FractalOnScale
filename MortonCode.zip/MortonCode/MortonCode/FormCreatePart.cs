﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesRaster;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.esriSystem;

namespace MortonCode
{
    public partial class FormCreatePart : Form
    {
        public FormCreatePart()
        {
            InitializeComponent();
        }

        private string maxLength;
        private string minLength;
        private string meanLength;
        private string yardStickLength;
        public string strFilePath;
        public string strFileName;
        private string layerName;
        private ISpatialReference pSpatialRef;

        private int chunksize = 300;

        private IPolyline Coastline;
        private double radius;

        private IGeometryCollection pGeometryCollection;
        private IPoint startCenterPoint;
        private IPoint secondCenterPoint;
        public IPoint newCP;

        private IPoint presentCenterPoint;

        private IPolygon startCirclePolygon;
        private IPolygon endCirclePolygon;


        private List<IPoint> initialCenterPoints;
        private List<IPoint> resultCenterPoints;

        private IWorkspace OpenShapfileWorkspace(string ShapeFilePath)
        {
            IWorkspace ws = null;
            IWorkspaceFactory wsf = new ShapefileWorkspaceFactoryClass(); //using DataSourcesFile
            if (ShapeFilePath != null)
            {
                ws = wsf.OpenFromFile(ShapeFilePath, 0);
            }
            return ws;
        }

        private IFields CreateFieldsCollection(ISpatialReference spatialReference, esriGeometryType geometryType)
        {
            IFeatureClassDescription fcDesc = new FeatureClassDescriptionClass();
            IObjectClassDescription ocDesc = fcDesc as IObjectClassDescription;

            IFields fields = ocDesc.RequiredFields;
            IFieldsEdit fieldsEdit = fields as IFieldsEdit;

            int shapeFieldIndex = fields.FindField(fcDesc.ShapeFieldName);
            IField shapeField = fields.get_Field(shapeFieldIndex);

            IGeometryDef geometryDef = shapeField.GeometryDef;
            IGeometryDefEdit geometryDefEdit = geometryDef as IGeometryDefEdit;

            geometryDefEdit.GeometryType_2 = geometryType;
            geometryDefEdit.GridCount_2 = 1;
            geometryDefEdit.set_GridSize(0, 0);
            geometryDefEdit.SpatialReference_2 = spatialReference;

            return fields;
        }

        private IFeatureClass CreateNewFeatureClass(IWorkspace pWS, String featureClassName, IFields pFields, esriFeatureType pEsriFeatureType)
        {
            IFeatureClassDescription fcDesc = new FeatureClassDescriptionClass();
            IObjectClassDescription ocDesc = fcDesc as IObjectClassDescription;
            IFieldChecker pFieldChecker = new FieldCheckerClass();
            IEnumFieldError pEnumFieldError = null;
            IFields validatedFields = null;
            IFeatureWorkspace pFeatureWorkspace = pWS as IFeatureWorkspace;
            pFieldChecker.ValidateWorkspace = pWS;
            pFieldChecker.Validate(pFields, out pEnumFieldError, out validatedFields);

            IFeatureClass pFeatureClass = pFeatureWorkspace.CreateFeatureClass(featureClassName, validatedFields, ocDesc.InstanceCLSID, ocDesc.ClassExtensionCLSID, pEsriFeatureType, fcDesc.ShapeFieldName, "");
            return pFeatureClass;
        }

        private void AddGeometryColToFeatureClass(IGeometryCollection pGeometryCollection, IFeatureClass pFeatureClass)
        {
            IFeatureCursor pFeatureCursor;
            IFeatureBuffer pFeatureBuffer;

            pFeatureCursor = pFeatureClass.Insert(true);
            pFeatureBuffer = pFeatureClass.CreateFeatureBuffer();

            IFields pFields;
            IField pField;

            pFields = pFeatureClass.Fields;


            for (int i = 0; i < pGeometryCollection.GeometryCount; i++)
            {
                IGeometry pCurrentGeometry = pGeometryCollection.get_Geometry(i) as IGeometry;

                for (int n = 1; n <= pFields.FieldCount - 1; n++)
                {
                    pField = pFields.get_Field(n);

                    if (pField.Type == esriFieldType.esriFieldTypeGeometry)
                    {

                        pFeatureBuffer.set_Value(n, pCurrentGeometry);


                    }

                }
                pFeatureCursor.InsertFeature(pFeatureBuffer);
            }
            pFeatureCursor.Flush();

        }

        //Geometry Type must be point polyline polygon...
        public void CreateShpfile(String featureClassName, IGeometryCollection pGeometryCollection)
        {
            //GetWorkPath();
            IWorkspace pWS = OpenShapfileWorkspace(this.strFilePath);
            
            ISpatialReference pSpatialReference = this.pSpatialRef;
            IGeometry pGeometry = pGeometryCollection.get_Geometry(0);
            esriGeometryType GeometryType = pGeometry.GeometryType;
            IFields pFields = CreateFieldsCollection(pSpatialReference, GeometryType);
            IFeatureClass pFeatureClass = CreateNewFeatureClass(pWS, featureClassName, pFields, esriFeatureType.esriFTSimple);
            AddGeometryColToFeatureClass(pGeometryCollection, pFeatureClass);
            MessageBox.Show("The shapefile: " + featureClassName + " has been saved in the same directory");
        }

        private ICircularArc CreateCircleArc(IPoint point, double radius, bool isCounterCW)
        {
            ICircularArc circularArc = new CircularArcClass();
            IConstructCircularArc2 constructCircularArc = circularArc as IConstructCircularArc2;
            constructCircularArc.ConstructCircle(point, radius, isCounterCW);
            circularArc.SpatialReference = this.pSpatialRef;
            return circularArc;
        }

        private IPolygon Arc2Polygon(ICircularArc Arc)
        {
            ISegmentCollection pSegCol = new RingClass();
            object obj = Type.Missing;
            pSegCol.AddSegment((ISegment)Arc, ref obj, ref obj);
            //enclose ring make it valid
            IRing pRing;
            pRing = pSegCol as IRing;
            pRing.Close();
            IGeometryCollection pPolygonCol = new PolygonClass();
            pPolygonCol.AddGeometry(pRing, ref obj, ref obj);
            IPolygon circlePolygon = (IPolygon)pPolygonCol;
            // mirror spatial referrence
            circlePolygon.SpatialReference = this.pSpatialRef;
            return circlePolygon;
        }

        private IPoint CreateNewCenterPoint3(IPoint presentCP)
        {
            ICircularArc presentCA = null;
            IConstructCircularArc2 constructCircularArc = null;
            IGeometry intersectPoints = null;
            ISegmentCollection segC = null;
            IPolyline circlePolyline = null;
            ITopologicalOperator2 topOperator = null;
            IPointCollection PointColl = null;
            IEnumVertex pEnumVertex = null;
            IClone coastlineClone = null;
            IPolycurve2 pPolyCurve = null;
            IGeometryCollection geoColl = null;
            IPoint newCenter = null;
            IPath resultPath = null;
            IGeometryCollection lineColl = null;
            IPolyline line = null;
            IRelationalOperator pRelOperator = null;
            try
            {
                //CREATE ARC
                presentCA = new CircularArcClass();
                constructCircularArc = presentCA as IConstructCircularArc2;
                constructCircularArc.ConstructCircle(presentCP, radius, false);
                presentCA.SpatialReference = this.pSpatialRef;
                //ARC 2 POLYLINE
                segC = new PolylineClass();
                segC.AddSegment((ISegment)presentCA);
                circlePolyline = (IPolyline)segC;
                circlePolyline.SpatialReference = this.pSpatialRef;
                //GET INTERSECTIONS
                topOperator = circlePolyline as ITopologicalOperator2;
                intersectPoints = topOperator.Intersect(Coastline, esriGeometryDimension.esriGeometry0Dimension);
                PointColl = (IPointCollection)intersectPoints;
                //SPLIT COASTLINE
                pEnumVertex = PointColl.EnumVertices;
                //COPY COASTLINE 
                coastlineClone = Coastline as IClone;
                pPolyCurve = coastlineClone.Clone() as IPolycurve2;
                pPolyCurve.SplitAtPoints(pEnumVertex, false, true, 0.1);

                geoColl = pPolyCurve as IGeometryCollection;

                newCenter = new PointClass(); ;

                for (int i = 0; i < geoColl.GeometryCount; i++)
                {
                    resultPath = new PathClass();
                    resultPath = (IPath)geoColl.get_Geometry(i);
                    lineColl = new PolylineClass();
                    lineColl.AddGeometry(resultPath);
                    line = (IPolyline)lineColl;
                    pRelOperator = (IRelationalOperator)line;
                    if (pRelOperator.Touches(presentCP) || pRelOperator.Contains(presentCP))
                    {
                        newCenter = resultPath.ToPoint;
                        newCenter.SpatialReference = this.pSpatialRef;
                    }
                }

                return newCenter;
            }
            finally
            {

            }

        }

        private IGeometryCollection GenerateYardSticks(IGeometryCollection verticesColl)
        {
            IPoint startPT = new PointClass();
            IPoint endPT = new PointClass();
            IGeometryCollection yardstickColl = new GeometryBagClass();
            ISegmentCollection yardsegColl = new PolylineClass();
            object obj = Type.Missing;
            for (int i = 0; i < verticesColl.GeometryCount; i++)
            {
                if (i < verticesColl.GeometryCount - 1)
                {
                    ILine pLine = new LineClass();

                    startPT = verticesColl.get_Geometry(i) as IPoint;
                    endPT = verticesColl.get_Geometry(i + 1) as IPoint;
                    pLine.PutCoords(startPT, endPT);
                    yardsegColl.AddSegment(pLine as ISegment, ref obj, ref obj);
                }
                else
                {
                    //MessageBox.Show(i+" yardsticks generated");
                }
            }
            IPolyline pPolyline = (IPolyline)yardsegColl;
            yardstickColl.AddGeometry(pPolyline, ref obj, ref obj);
            return yardstickColl;
        }

        
        private void btn_yes_Click(object sender, EventArgs e)
        {
            strFilePath = @"D:\study\ao\MortonCode\UKCoastline";
            IWorkspace ws = OpenShapfileWorkspace(strFilePath);
            IFeatureWorkspace pFWS = ws as IFeatureWorkspace;
            //openFileDialog1.Filter = "shapefile(*.shp)|*.shp";
            //openFileDialog1.InitialDirectory = strFilePath;
            //string verticepartname=null;
            //if (openFileDialog1.ShowDialog() == DialogResult.OK)
            //{
            //    int index = openFileDialog1.FileName.LastIndexOf(@"\");
            //    strFilePath = openFileDialog1.FileName.Substring(0, index);
            //    int length = openFileDialog1.FileName.Length - strFilePath.Length - 1;
            //    verticepartname = openFileDialog1.FileName.Substring(index + 1, length);
            //}
            //Only one feature in the featureclass
            IFeatureClass fcCoastLine = pFWS.OpenFeatureClass("UK_Coastline");
            IFeature fCoastLine = fcCoastLine.GetFeature(0);
            IPolyline polylineCoast = new PolylineClass();
            polylineCoast = fCoastLine.ShapeCopy as IPolyline;

            Coastline = fCoastLine.ShapeCopy as IPolyline;
            this.pSpatialRef = Coastline.SpatialReference;

            
            yardStickLength ="16000";
            radius = double.Parse(yardStickLength);

            IFeatureClass fcVertices = pFWS.OpenFeatureClass("Vertices");
            IFeatureClass fcYards = pFWS.OpenFeatureClass("Yardsticks");
            IQueryFilter queryFilter = new QueryFilterClass();
            int count = fcVertices.FeatureCount(queryFilter);
            MessageBox.Show(count.ToString());
            startCenterPoint = fcVertices.GetFeature(count - 1).ShapeCopy as IPoint;

            ICircularArc endcircle;
            endcircle = CreateCircleArc(polylineCoast.ToPoint, radius, false);
            //Initialize startcirlcePolygon
            endCirclePolygon = Arc2Polygon(endcircle);

            secondCenterPoint = CreateNewCenterPoint3(startCenterPoint);
            pGeometryCollection = new GeometryBagClass();

            pGeometryCollection.AddGeometry(secondCenterPoint);

            presentCenterPoint = secondCenterPoint;
            IRelationalOperator relCircle = endCirclePolygon as IRelationalOperator;

            while (!relCircle.Contains(presentCenterPoint))
            {
                presentCenterPoint = CreateNewCenterPoint3(presentCenterPoint);
                pGeometryCollection.AddGeometry(presentCenterPoint);

                if (pGeometryCollection.GeometryCount == chunksize)
                {
                    break;
                }
            }

            //int fileindex=int.Parse((verticepartname[verticepartname.Length-1-4]).ToString())+1;
            AddGeometryColToFeatureClass(pGeometryCollection, fcVertices);
            //if (MessageBox.Show("Vertice number: "+pGeometryCollection.GeometryCount.ToString() + " Save new vertices to shapefile?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes)
            //{
            //    AddGeometryColToFeatureClass(pGeometryCollection,fcVertices);
            //}
            IGeometryCollection pGeomeryCollforyards = new GeometryBagClass();
            pGeomeryCollforyards.AddGeometry(startCenterPoint);
            pGeomeryCollforyards.AddGeometryCollection(pGeometryCollection);
            IGeometryCollection yardstickColl = new GeometryBagClass();
            yardstickColl = GenerateYardSticks(pGeomeryCollforyards);
            AddGeometryColToFeatureClass(yardstickColl, fcYards);
            //...Create yardstick using the generated vertices...
            //if (MessageBox.Show("Save new yardsticks to shapefile?", "Note", MessageBoxButtons.YesNo) == DialogResult.Yes)
            //{
            //    IGeometryCollection yardstickColl= GenerateYardSticks(pGeometryCollection);
            //    AddGeometryColToFeatureClass(pGeometryCollection, fcYards);
            //}

            if (pGeometryCollection.GeometryCount == chunksize)
            {
                Application.Restart();
            }
            else
            {
                MessageBox.Show("Finished!");
            }
            Application.Exit();
        }

        private void btn_no_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormCreatePart_Shown(object sender, EventArgs e)
        {
            btn_yes.PerformClick();
        }
    }
}
