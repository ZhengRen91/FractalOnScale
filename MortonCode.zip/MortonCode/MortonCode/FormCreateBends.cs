﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.DataSourcesRaster;
using ESRI.ArcGIS.Geoprocessing;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.DataSourcesFile;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.esriSystem;
using System.Runtime.InteropServices;


namespace MortonCode
{
    public partial class FormCreateBends : Form
    {
        public FormCreateBends()
        {
            InitializeComponent();
        }

        private string verticeName;
        private string bendsName;
        private string strFilePath1;
        private string strFilePath2;
        private ISpatialReference pSpatialRef;
        private IGeometryCollection pGeometryCollection;
        private List<BendPoint> bplist;
        private List<double> lengthList;
        private List<BendPoint> dividerlist;
        private List<BendPoint> resultlist;
        
        private BendPoint divider;
        

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "shapefile(*.shp)|*.shp";
            openFileDialog1.InitialDirectory = @"D:\study\ao\MortonCode\Bends";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = openFileDialog1.FileName;
                int index = openFileDialog1.FileName.LastIndexOf(@"\");
                strFilePath1 = openFileDialog1.FileName.Substring(0, index);
                //MessageBox.Show(strFilePath1.ToString());
                int length = openFileDialog1.FileName.Length - strFilePath1.Length - 1;
                verticeName = openFileDialog1.FileName.Substring(index + 1, length);
                //MessageBox.Show(verticeName);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "shapefile(*.shp)|*.shp";
            saveFileDialog1.InitialDirectory = @"D:\study\ao\MortonCode\Bends";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = saveFileDialog1.FileName;
                int index = saveFileDialog1.FileName.LastIndexOf(@"\");
                strFilePath2 = saveFileDialog1.FileName.Substring(0, index);
                int length = saveFileDialog1.FileName.Length - strFilePath2.Length - 1;
                bendsName = saveFileDialog1.FileName.Substring(index + 1, length);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.strFilePath1 == null) 
            {
                MessageBox.Show("Choose path");
                return;
            }

            IWorkspace pWorkspace1 = OpenShapfileWorkspace(strFilePath1);
            IFeatureWorkspace pFeatureWS1 = pWorkspace1 as IFeatureWorkspace;
            IFeatureClass fcVertice = pFeatureWS1.OpenFeatureClass(this.verticeName);
            this.pSpatialRef = fcVertice.GetFeature(0).ShapeCopy.SpatialReference;
          
            bplist = new List<BendPoint>();
            IQueryFilter queryFilter = new QueryFilterClass();
            IFeatureCursor pFCursor1 = fcVertice.Update(queryFilter, false);
            IFeature pFeature1 = pFCursor1.NextFeature();

            while (pFeature1 != null)
            {
                BendPoint ptTemp = new BendPoint();
                IPoint pPoint = pFeature1.ShapeCopy as IPoint;
                ptTemp.X = pPoint.X;
                ptTemp.Y = pPoint.Y;
                ptTemp.Id = pFeature1.OID;                
                bplist.Add(ptTemp);
                pFeature1 = pFCursor1.NextFeature();
            }
            MessageBox.Show(bplist.Count.ToString());

            int bplistcount = bplist.Count;
            BendPoint firstPoint = bplist[0];
            BendPoint lastPoint = bplist[bplistcount - 1];
            BaseLine newBaseLine = CreateBaseLine(firstPoint, lastPoint);

            //List<BendPoint> crossPointlist = new List<BendPoint>();
            //BendPoint pXCross = new BendPoint();

            for (int i = 1; i < bplistcount - 1; i++)
            {
                bplist[i].Length = GetDistance(bplist[i], newBaseLine);
                //pXCross = GetCrossPoint(bplist[i], newBaseLine);
                //crossPointlist.Add(pXCross);
            }

            divider = new BendPoint();            
            double maxlength = bplist.Max(t => t.Length); //Alternatively use MoreLinq 'MaxBy'
            divider = bplist.First(t=>t.Length==maxlength);
            MessageBox.Show("First diviver point: " + divider.Id.ToString() + " " + divider.Length.ToString());

            dividerlist = new List<BendPoint>();
            //dividerlist.Add(firstPoint);
            //dividerlist.Add(lastPoint);
            //dividerlist.Add(divider);
            //dividerlist.OrderBy(a=>a.Id);
            //MessageBox.Show("sorted divider");


            lengthList = new List<double>(); //without first and end in the result at first two
            //foreach (double l in lengthList) 
            //{
            //    MessageBox.Show(l.ToString());
            //}

            dividerlist = DPR(bplist, 0); //with first and end in the result at first two

            for (int i = 0; i < lengthList.Count; i++) 
            {
                dividerlist[i + 2].Length = lengthList[i];
            }
                
            // sort result according to ID
            resultlist = new List<BendPoint>();
            resultlist = dividerlist.OrderBy(a => a.Id).ToList();           

            MessageBox.Show("Length calculation finished!");
           
            //int crosslistcount = crossPointlist.Count;
            //pGeometryCollection = new GeometryBagClass();
            //lengthList = new List<double>();
            //for (int i = 0; i < crossPointlist.Count; i++) 
            //{
            //    IPoint pCrossPoint = new PointClass();
            //    pCrossPoint.PutCoords(crossPointlist[i].X, crossPointlist[i].Y);
            //    pGeometryCollection.AddGeometry(pCrossPoint);
            //    lengthList.Add(crossPointlist[i].Length);
            //}
            //if (strFilePath2 != null && bendsName != null) 
            //{
            //    CreateShpfile(bendsName,pGeometryCollection);              
            //} 

            DialogResult result = MessageBox.Show("Add length ?", "Note", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                ////Add new field
                //AddFieldtoExistingFeatureClass(fcVertice, "Length", esriFieldType.esriFieldTypeDouble);
                //MessageBox.Show("Length field Added!");
                UpDateValuesToCurrentFeatureClass(fcVertice);
                MessageBox.Show("The length values have been saved.");
            }
           
        }

        private List<BendPoint> DPR(List<BendPoint> Points, Double tol) 
        {
            if (Points == null || Points.Count < 3) 
            {
                return Points;
            }

            int first = 0;
            int last = Points.Count - 1;
            List<int> indexToKeep = new List<int>();
            indexToKeep.Add(first);
            indexToKeep.Add(last);

            while (Points[first].Equals(Points[last])) 
            {
                last--;
            }

            DPR(Points,first,last,tol,ref indexToKeep);

            List<BendPoint> returnPoints = new List<BendPoint>();
            //indexToKeep.Sort();
            foreach (int index in indexToKeep) 
            {
                returnPoints.Add(Points[index]);
            }

            return returnPoints;

        }

        private void DPR(List<BendPoint> points, int first, int last, Double tol, ref List<int> pointsIndexKeep) 
        {
            double Dmax = 0.00001;
            int indexFarthest = 0;

            for (int index = first; index < last; index++) 
            {
                BaseLine bl = new BaseLine();
                bl = CreateBaseLine(points[first],points[last]);
                BendPoint bp = new BendPoint();
                bp = points[index];
                double dis = GetDistance(bp,bl);
                
                if (dis > Dmax) 
                {
                    Dmax = dis;
                    indexFarthest = index;                   
                }
            }


            if (Dmax > tol && indexFarthest != 0)
            {
                lengthList.Add(Dmax);
                pointsIndexKeep.Add(indexFarthest);
                // Recursive call
                DPR(points, first, indexFarthest, tol, ref pointsIndexKeep);
                DPR(points, indexFarthest, last, tol, ref pointsIndexKeep);               
            }   

        }
        

      
        private void refreshLength(List<BendPoint> list) 
        {
            foreach (BendPoint pt in list)
            {
                pt.Length = 0;
            }
        }

        private BendPoint GetDivider(BendPoint pStart, BendPoint pEnd) 
        {
            BaseLine newBaseLine = CreateBaseLine(pStart, pEnd);
            lengthList = new List<double>();
            refreshLength(bplist);
            for (int i = pStart.Id+1; i < pEnd.Id; i++) 
            {
                bplist[i].Length = GetDistance(bplist[i], newBaseLine);
                lengthList.Add(bplist[i].Length);
            }
            divider = new BendPoint();
            double maxlength = lengthList.Max(); //Alternatively use MoreLinq 'MaxBy'
            divider = bplist.First(t => t.Length == maxlength);
            return divider;
        }

        

        //public interface IBendPoint 
        //{
        //    //封装ctrl R E
        //    double x;

        //    public double X
        //    {
        //        get { return x; }
        //        set { x = value; }
        //    }
        //    double y;

        //    public double Y
        //    {
        //        get { return y; }
        //        set { y = value; }
        //    }
        //}

        
        public class BendPoint
        {
            private double x;

            public double X
            {
                get { return x; }
                set { x = value; }
            }
            private double y;

            public double Y
            {
                get { return y; }
                set { y = value; }
            }

            private int id;

            public int Id
            {
                get { return id; }
                set { id = value; }
            }
            private double length=0;

            public double Length
            {
                get { return length; }
                set { length = value; }
            }
        }

        public class BaseLine
        {
            private double a;

            public double A
            {
                get { return a; }
                set { a = value; }
            }
          
            private double b;

            public double B
            {
                get { return b; }
                set { b = value; }
            }

            private double c;

            public double C
            {
                get { return c; }
                set { c = value; }
            }


           
        }

        private BaseLine CreateBaseLine(BendPoint p1, BendPoint p2) 
        {
            double a = p2.Y - p1.Y;
            double b = p1.X - p2.X;
            double c = p2.X * p1.Y - p1.X * p2.Y;
            BaseLine bline1 = new BaseLine {A=a,B=b,C=c };
            return bline1;
        }

        private double GetDistance(BendPoint bp, BaseLine bl) // Use Heron's formula is better, avoid 0.0000009999 problem
        {
            double d = Math.Abs(bp.X * bl.A + bp.Y * bl.B + bl.C)/Math.Sqrt(bl.A*bl.A+bl.B*bl.B);
            return d;
        }

        private BendPoint GetCrossPoint(BendPoint bp, BaseLine baseline) 
        {
            double k1 = -baseline.A / baseline.B;
            double b1 = -baseline.C / baseline.B;
            double k2 = -1 / k1;
            double b2 = bp.Y - k2 * bp.X;
            
            BendPoint crossPT = new BendPoint();
            crossPT.X=(b2-b1)/(k1-k2);
            crossPT.Y = crossPT.X * k1 + b1;
            crossPT.Id = bp.Id;
            crossPT.Length = bp.Length;
            return crossPT;           
        }


        private IWorkspace OpenShapfileWorkspace(string ShapeFilePath)
        {
            IWorkspace ws = null;
            IWorkspaceFactory wsf = new ShapefileWorkspaceFactoryClass(); //using DataSourcesFile
            if (ShapeFilePath != null)
            {
                ws = wsf.OpenFromFile(ShapeFilePath, 0);
            }
            return ws;
        }

        private IFields CreateFieldsCollection(ISpatialReference spatialReference, esriGeometryType geometryType)
        {
            IFeatureClassDescription fcDesc = new FeatureClassDescriptionClass();
            IObjectClassDescription ocDesc = fcDesc as IObjectClassDescription;

            IFields fields = ocDesc.RequiredFields;
            IFieldsEdit fieldsEdit = fields as IFieldsEdit;

            int shapeFieldIndex = fields.FindField(fcDesc.ShapeFieldName);
            IField shapeField = fields.get_Field(shapeFieldIndex);

            IGeometryDef geometryDef = shapeField.GeometryDef;
            IGeometryDefEdit geometryDefEdit = geometryDef as IGeometryDefEdit;

            geometryDefEdit.GeometryType_2 = geometryType;
            geometryDefEdit.GridCount_2 = 1;
            geometryDefEdit.set_GridSize(0, 0);
            geometryDefEdit.SpatialReference_2 = spatialReference;

            return fields;
        }

        private IFeatureClass CreateNewFeatureClass(IWorkspace pWS, String featureClassName, IFields pFields, esriFeatureType pEsriFeatureType)
        {
            IFeatureClassDescription fcDesc = new FeatureClassDescriptionClass();
            IObjectClassDescription ocDesc = fcDesc as IObjectClassDescription;
            IFieldChecker pFieldChecker = new FieldCheckerClass();
            IEnumFieldError pEnumFieldError = null;
            IFields validatedFields = null;
            IFeatureWorkspace pFeatureWorkspace = pWS as IFeatureWorkspace;
            pFieldChecker.ValidateWorkspace = pWS;
            pFieldChecker.Validate(pFields, out pEnumFieldError, out validatedFields);

            IFeatureClass pFeatureClass = pFeatureWorkspace.CreateFeatureClass(featureClassName, validatedFields, ocDesc.InstanceCLSID, ocDesc.ClassExtensionCLSID, pEsriFeatureType, fcDesc.ShapeFieldName, "");
            return pFeatureClass;
        }

        private void AddGeometryColToFeatureClass(IGeometryCollection pGeometryCollection, IFeatureClass pFeatureClass)
        {
            IFeatureCursor pFeatureCursor;
            IFeatureBuffer pFeatureBuffer;

            pFeatureCursor = pFeatureClass.Insert(true);
            pFeatureBuffer = pFeatureClass.CreateFeatureBuffer();

            IFields pFields;
            IField pField;

            pFields = pFeatureClass.Fields;


            for (int i = 0; i < pGeometryCollection.GeometryCount; i++)
            {
                IGeometry pCurrentGeometry = pGeometryCollection.get_Geometry(i) as IGeometry;

                for (int n = 1; n <= pFields.FieldCount - 1; n++)
                {
                    pField = pFields.get_Field(n);

                    if (pField.Type == esriFieldType.esriFieldTypeGeometry)
                    {

                        pFeatureBuffer.set_Value(n, pCurrentGeometry);

                    }
                    

                }
                pFeatureCursor.InsertFeature(pFeatureBuffer);
            }
            pFeatureCursor.Flush();

        }

        private void AddValuesToFeatureClass(IGeometryCollection pGeometryCollection, IFeatureClass pFeatureClass)
        {
            IFeatureCursor pFeatureCursor;
            IFeatureBuffer pFeatureBuffer;

            pFeatureCursor = pFeatureClass.Insert(true);
            pFeatureBuffer = pFeatureClass.CreateFeatureBuffer();

            IFields pFields;
            IField pField;

            pFields = pFeatureClass.Fields;


            for (int i = 0; i < pGeometryCollection.GeometryCount; i++)
            {
                IGeometry pCurrentGeometry = pGeometryCollection.get_Geometry(i) as IGeometry;

                for (int n = 1; n <= pFields.FieldCount - 1; n++)
                {
                    pField = pFields.get_Field(n);

                    if (pField.Type == esriFieldType.esriFieldTypeGeometry)
                    {

                        pFeatureBuffer.set_Value(n, pCurrentGeometry);

                    }

                    //add lengths
                    if (pField.Type == esriFieldType.esriFieldTypeDouble) 
                    {
                        pFeatureBuffer.set_Value(n, lengthList[i]);
                    }


                }
                pFeatureCursor.InsertFeature(pFeatureBuffer);
            }
            pFeatureCursor.Flush();

        }

        private void UpDateValuesToCurrentFeatureClass(IFeatureClass pFeatureClass)
        {
            IFeatureCursor pFeatureCursor;
            IFeatureBuffer pFeatureBuffer;
            IQueryFilter queryFilter = new QueryFilterClass();
            pFeatureCursor = pFeatureClass.Update(queryFilter, false);
            pFeatureBuffer = pFeatureClass.CreateFeatureBuffer();

            IFields pFields;
            IField pField;

            pFields = pFeatureClass.Fields;
            int fieldIndex = pFields.FindField("Length");

            IFeature feature = null;
            int i = 0;
            while ((feature = pFeatureCursor.NextFeature()) != null) 
            {
                feature.set_Value(fieldIndex, resultlist[i].Length);
                pFeatureCursor.UpdateFeature(feature);
                i++;
            }

            Marshal.ReleaseComObject(pFeatureCursor);

        }

        private void AddFieldtoExistingFeatureClass(IFeatureClass pFC, string addFieldName, esriFieldType addFieldType) 
        {

            ISchemaLock schemaLock = (ISchemaLock)pFC;

            try
            {
                // A try block is necessary, as an exclusive lock may not be available.
                schemaLock.ChangeSchemaLock(esriSchemaLock.esriExclusiveSchemaLock);

                // Add the field.
                IField pField = new FieldClass();
                IFieldEdit2 pFieldEdit = pField as IFieldEdit2;
                pFieldEdit.Type_2 = addFieldType;
                pFieldEdit.Name_2 = addFieldName;
                pFC.AddField(pField);
            }
            catch (Exception exc)
            {
                // Handle this in a way appropriate to your application.
                Console.WriteLine(exc.Message);
            }
            finally
            {
                // Set the lock to shared, whether or not an error occurred.
                schemaLock.ChangeSchemaLock(esriSchemaLock.esriSharedSchemaLock);
            }
           

        }

        //Geometry Type must be point polyline polygon...
        public void CreateShpfile(String featureClassName, IGeometryCollection pGeometryCollection)
        {
            //GetWorkPath();
            IWorkspace pWS = OpenShapfileWorkspace(strFilePath2);
            ISpatialReference pSpatialReference = this.pSpatialRef;
            IGeometry pGeometry = pGeometryCollection.get_Geometry(0);
            esriGeometryType GeometryType = pGeometry.GeometryType;
            IFields pFields = CreateFieldsCollection(pSpatialReference, GeometryType);
            IFeatureClass pFeatureClass = CreateNewFeatureClass(pWS, featureClassName, pFields, esriFeatureType.esriFTSimple);
            //Add new field
            AddFieldtoExistingFeatureClass(pFeatureClass, "Length", esriFieldType.esriFieldTypeDouble);
            MessageBox.Show("Length field Added!");
            AddValuesToFeatureClass(pGeometryCollection, pFeatureClass);
            MessageBox.Show("The shapefile: " + featureClassName + " has been saved.");
        }
    }
}
